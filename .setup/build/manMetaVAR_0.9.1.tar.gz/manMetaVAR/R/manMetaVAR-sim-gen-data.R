#' Simulation Replication - GenData
#'
#' @details This function is executed via the `Sim` function.
#'
#' @author Ivan Jacob Agaloos Pesigan
#'
#' @return The output is saved as an external file in `output_folder`.
#'
#' @inheritParams Template
#' @export
#' @keywords manMetaVAR gendata simulation
SimGenData <- function(taskid,
                       repid,
                       output_folder,
                       params_taskid,
                       seed,
                       suffix,
                       overwrite,
                       integrity) {
  # Do not include default arguments here.
  # Do not run on its own. Use the `Sim` function.
  fn_output <- SimFN(
    output_type = "data",
    output_folder = output_folder,
    suffix = suffix
  )
  run <- .SimCheck(
    fn = fn_output,
    overwrite = overwrite,
    integrity = integrity
  )
  if (run) {
    tryCatch(
      {
        set.seed(seed)
        con <- file(fn_output)
        saveRDS(
          object = GenData(
            n = params_taskid$n,
            time = params_taskid$time,
            theta = params_taskid$theta
          ),
          file = con
        )
        close(con)
        .SimChMod(fn_output)
      },
      error = function(cond) {
        message(paste("error:", "SimGenData"))
        message("Here's the original error message:")
        message(conditionMessage(cond))
        cat(
          paste(
            "check",
            "taskid:",
            taskid,
            "repid:",
            repid,
            "\n"
          )
        )
      },
      warning = function(cond) {
        message(paste("error:", "SimGenData"))
        message("Here's the original warning message:")
        message(conditionMessage(cond))
        cat(
          paste(
            "check",
            "taskid:",
            taskid,
            "repid:",
            repid,
            "\n"
          )
        )
      }
    )
  }
}
